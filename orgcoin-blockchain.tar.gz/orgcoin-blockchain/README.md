orgcoin-blockchain
==================

Checkpoint for orgcoin blockchain to get around a corrupt block problem deep in the chain.
Only use this if your client has trouble downloading the blockchain
./orgcoind getinfo 
Returns 0 blocks after 30 or more minutes of running.
Otherwise you DO NOT NEED THIS!
